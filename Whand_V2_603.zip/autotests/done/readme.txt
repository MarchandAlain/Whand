repeat.txt is not a Whand script
when present in the autotest directory
it allows a single script name (with .txt extension)
to be autotested 1000 times instead of normal autotest
execution can be stopped at any time with Ctrl-C

Before running this test, edit 'whand_parameters.py' as: 
    Fatal_use_before=True
    Random_update_order = True 