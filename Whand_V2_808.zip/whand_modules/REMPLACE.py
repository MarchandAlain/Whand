# -*- coding: ISO-8859-1 -*-
"""
Lecture de tous les fichiers d'un r�pertoire - Python 3
et modifications de texte oldtext -> newtext
r�-enregistrement des fichiers avec un nom modifi� (ou pas)
METTRE LES FICHIERS A TRAITER DANS UN REPERTOIRE SEPARE
CE PROGRAMME SE MODIFIE LUI M�ME SI LES FICHIERS SONT REMPLACES
"""
import os

" param�trage "
extensionIn = ".py"               # extension identifiant les fichier sources
extensionOut =".py"             # extension identifiant les fichier modifi�s
##prefixe="r"                           # identifiant les fichiers modifi�s (si vide: �crase)
prefixe=""                              # �craser les anciens fichiers
critere=[]                                # s'applique uniquement aux lignes contenant
exclude=[]                              # s'applique uniquement aux lignes ne contenant pas
changetext=[("copy_node", "copy_node")]

rep= os.getcwd()                    # r�pertoire courant o� se trouve ce programme-ci
print("Acc�s �",rep)

" Liste des fichiers sources " 
names = [os.path.normcase(nom) for nom in os.listdir(rep) if os.path.splitext(nom)[1] == extensionIn]       
filelist = [os.path.join(rep, nom) for nom in names]

print(names)

" Lire chaque fichier "
for nom in filelist:
    change=False
    with open(nom,"r") as fichierin:             # ouverture du fichier d'entr�e
        print("Ouvre: ", nom.split("\\")[-1])
        brut=fichierin.read()                          # lecture du contenu complet
    
    " analyser le contenu par ligne "
    newlines=[]
    all_lignes=brut.split("\n")                     # d�coupage en lignes
    for ligne in all_lignes:
        # v�rifier crit�res
        if critere:
            ok=False
            for crit in critere:
                if crit in ligne: ok=True
        else:
            ok=True
        for crit in exclude:
            if crit in ligne: ok=False
        # remplacer
        newli=ligne
        if ok:
            for oldtext,newtext in changetext:
                if oldtext in ligne:
                    print(ligne)
                    newli=ligne.replace(oldtext, newtext)
                    print(newli)
                    change=True
        newlines+=[newli]
    # �criture
    if change or prefixe:
        newnom=os.path.join(rep, prefixe+os.path.splitext(os.path.split(nom)[1])[0]+extensionOut)
        print("    Ecrit dans: ", newnom.split("\\")[-1])
        with open(newnom,"w") as new:                           # ouverture du fichier de sortie
            for ligne in newlines:
                  new.write(ligne+"\n")

print("Modifications effectu�es.")







