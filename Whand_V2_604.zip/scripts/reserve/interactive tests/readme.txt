Interactive tests contains earlier or incomplete versions of scripts that may not function as such.
They provide examples of error messages.