*** bricks\readme.txt - updated by Alain Marchand, july 2017 ***
The "bricks" subdirectory contains parts of programs that can be included as such in a script
or modified according to needs. The order of bricks in a script is indifferent.
The only requirement is that objects must not be defined more than once.
Some bricks (e.g.pulses.txt) create user-defined functions that may be called with various arguments
