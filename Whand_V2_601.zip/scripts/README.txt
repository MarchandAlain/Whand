*** scripts\readme.txt - updated by Alain Marchand, july 2017 ***
The "scripts" subdirectory must be present in the directory containing Whand program.
It is used by Whand to look for run files and scripts, as text files with extension ".txt". 
The name of scripts should be given in the run file, another text file.
The run file must be present in the "scripts" directory. 
This allows running several scripts in parallel or sequentially.
Scripts run in parallel if they are indicated in the run file on a single line, separated by commas.
Scripts run sequentially if they are on separate lines.
Scripts may be stored in subdirectories of the "scripts" directory (e.g. "my_scripts"). 
In this case, script names in the run file should be preceded by a path (e.g. "my_scripts\some_script")