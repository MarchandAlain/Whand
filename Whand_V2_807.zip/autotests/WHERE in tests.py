# -*- coding: ISO-8859-1 -*-
"""
Dans un projet, liste les lignes contenant une ou plusieurs variables pr�c�d�es de leur num�ro de ligne
La variable (ou tout texte) doit �tre d�finie "en dur" dans ce programme 
Tous les fichiers .py du r�pertoire courant sont trait�s, et quelques autres, hormis une liste d'exceptions
Le r�sultat va dans log.py, ce qui permet de b�n�ficier de la coloration syntaxique
"""
import os

#============================================================

cherche=["count"]        # chaines � rechercher (respecter la casse)

#============================================================

" param�trage "
extensionIn = ".txt"                                         # extension identifiant les fichier sources
do_not_process=["where.py", "log.py", "remplace.py", "six.py", "pifacedigitalio.py"]
also_process=[] # ["../whand_V2_8.py"]

" Liste des fichiers sources " 
rep= os.getcwd()                                            # r�pertoire courant o� se trouve ce programme-ci
print("Acc�s �",rep)
names = also_process+[os.path.normcase(nom) for nom in os.listdir(rep) if os.path.splitext(nom)[1] == extensionIn]       
filelist = [os.path.join(rep, nom) for nom in names]
##print("Fichiers � traiter :", names)

" Lire chaque fichier "
newlines=[]
for nom in filelist:
    if nom.split("\\")[-1] in do_not_process: continue
    with open(nom,"r") as fichierin:                # ouverture du fichier d'entr�e
        print("Ouvre: ", nom.split("\\")[-1])
        brut=fichierin.read()                            # lecture du contenu complet
    
    add_file="\n" if newlines else ""               # pas de ligne blanche au d�but
    add_file+="### "+nom.split("\\")[-1]+":"  # affichera nom du fichier source
    add_def=""                                             # affichera nom de la proc�dure
    
    " Analyser le contenu par ligne "
    all_lignes=brut.split("\n")                         # d�coupage en lignes
    quote=False
    for numligne, ligne in enumerate(all_lignes):
        ici=ligne.find("#")
        newli=ligne[:ici] if ici>=0 else ligne       # suppression des commentaires
        if '"""' in newli: quote=not quote          # suppression des infos 
            
        if not quote:
            if newli.strip(" ").startswith("def "):
                add_def="\n"+newli+"\n"            # nom de la proc�dure
            for ch in cherche:
                if ch in newli:                               # une chaine est pr�sente dans la ligne 
                    if newli.strip(" ").startswith("def "): # titres
                        newlines+=[add_file+"\n"+str(numligne+1)+": "+newli]
                    elif add_file and not add_def:  # titres hors d'une proc�dure
                        newlines+=[add_file+"\n"+str(numligne+1)+": "+newli]
                    else:
                        newlines+=[add_file+add_def+str(numligne+1)+": "+newli]
                    add_file=""
                    add_def=""
                    break
" Ecrire "
newnom=os.path.join(rep, "log.py")
print("    Ecrit dans: ", newnom.split("\\")[-1])
with open(newnom,"w") as new:                    # ouverture du fichier de sortie
    for ligne in newlines:
          new.write(ligne+"\n")

if not newlines: print("\nAucune occurrence !\n")
print("*** Termin� ***")







