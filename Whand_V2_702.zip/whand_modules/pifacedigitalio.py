# dummy interface module for tests outside raspy environment
from time import time as clock
def init():
##    print(clock(), "PiFace: init()")
    pass

def digital_write(port, status, chip=0):
##    print(clock(), "PiFace: digital_write", port, status, chip)
    pass

def digital_read(port, chip=0):
##    print(clock(), "PiFace: digital_read", port, status, chip)
    pass

def digital_write_pullup(port, status, chip=0):
##    print(clock(), "PiFace: digital_write_pullup", port, status, chip)
    pass

def PiFaceDigital(chip=0):
##    print(clock(), "PiFace: digital", chip)
    return chip

def InputEventListener(chip=0):
##    print(clock(), "Creating InputEventListener", chip)
    return Listener()

class Listener:
    def __init__(self):
        self.name=""                                                          
    def register(self, port, edge, callbackup):
##        print(clock(), "Listener.register", port, edge, callbackup)
        pass
    def activate(self):
##        print(clock(), "Listener.activate()")
        pass
    def deactivate(self):
##        print(clock(), "Listener.deactivate()")
        pass

IODIR_FALLING_EDGE="IODIR_FALLING_EDGE"
IODIR_RISING_EDGE="IODIR_RISING_EDGE"

