*** data\readme.txt - updated by Alain Marchand, 26 june 2017 ***
The "data" subdirectory must be present in the directory containing Whand program.
It is used by Whand to automatically store results. 
Result files are text files with names such as:
wh0624_01_1.e01, where
	0624 is the month and day of the experiment
	01 is the number of the experiment of this day (if several experiments are run)
	_1 is the number of the experimental box (if several boxes are used in parallel)
The result files can be analyzed using TraiteSK version 10j and above
The format for result file is defined in module whand_io.py
First data column represents times, stored in 1/10th of a second
Second data column contains event codes
The following event codes are appended to each result file

 1 :  front montant pr�sentation p�dale A
 2 :  front montant pr�sentation p�dale B
 3 :  front montant ouverture trou C
 4 :  front montant ouverture trou D
 5 :  front montant ouverture trou E
 6 :  front montant appui p�dale A
 7 :  front montant appui p�dale B
 8 :  front montant visite trou C
 9 :  front montant visite trou D
10 :  front montant visite trou E 
11 :  front montant visite mangeoire A vide 
12 :  front montant visite mangeoire B vide
13 :  front montant visite mangeoire A pleine
14 :  front montant visite mangeoire B pleine
15 :  front montant relachement p�dale OU fin visite trou ou DB ou ..
16 :  front montant distribution mangeoire A
17 :  front montant distribution mangeoire B
18 :  front montant enclenchement led A
19 :  front montant enclenchement led B
20:   front montant enclenchement led C
21 :  front montant enclenchement led D
22 :  front montant enclenchement led E
23 :  front montant enclenchement led F
24 :  front montant enclenchement son
25 :  front montant enclenchement lumi�re EA
26 :  front montant enclenchement injection
27 :  front montant enclenchement choc
28 :  front montant enclenchement stimulation
29 :  ACTIVITE front montant entree zone gauche
30 :  ACTIVITE front montant entree zone droite
41 :  r�traction p�dale A
42 :  r�traction p�dale B
43 :  fermeture trou C
44 :  fermeture trou D
45 :  fermeture trou E
46 :  relachement p�dale A
47 :  relachement p�dale B
48 :  fin visite trou C
49 :  fin visite trou D
50 :  fin visite trou E 
51 :  fin visite mangeoire A vide 
52 :  fin visite mangeoire B vide
53 :  fin visite mangeoire A pleine
54 :  fin visite mangeoire B pleine
56 :  fin distribution mangeoire A
57 :  fin distribution mangeoire B
58 :  fin led A
59 :  fin led B
60:   fin led C
61 :  fin led D
62 :  fin led E
63 :  fin led F
64 :  fin son
65 :  fin lumi�re EA
66 :  fin injection
67 :  fin choc
68 :  fin stimulation
69 :  fin zone gauche
70 :  fin zone droite
99 :  fin s�ance
