### whand_compile.py:
def adjust_store_list(sv):
766:         if applied(nam, Store):                                      

def finalize_user_functions(sv):
1323:                 block=applied(nm, nam)                       
1329:                 warn("\n"+Warn_never_applied+"\n"+nam)   

def is_fixed(nam):
1572:         if applied(nam, Load): return True
1573:         if applied(nam, Show): return True
1574:         if applied(nam, Unused): return True

def find_causes(sv):
1652:         counted=applied(nam, Count)                            
1654:         showed=applied(nam, Show)

def verif_stochastic(sv, tree=Special):
1817:                         if applied(A[0], sto):                                            
1819:                     if applied(A[0], Call):                                               
1840:                         if applied(x[0], sto):                                            
1842:                     if applied(x[0], Call):                                               

def verif_unused(sv):
1867:         unusedlist=[applied (x, Unused) for x in sv.Object[Unused].value]
1871:             elif applied(nam, Output):

def make_volatiles(sv):
1942:             if applied(nam, op):                        
1943:                 vlu=(op, (applied(nam, op), None, None), None)

def make_pin_list(sv):
2335:         if  applied(nam, Key):                                                     
2337:         elif applied(nam, Pin) and isnumber(nam[len(Pin)+1:-1]): 
2340:         elif applied(nam, Output) and isnumber(nam[len(Output)+1:-1]): 

### whand_controlpanel.py:
    def labelling(self, sv, element):                                                                        
158:                 if element in sv.Namedpinlist.values() or element in sv.Pinlist or applied(element, Output):  
162:                     if element in sv.Namedpinlist.values() or element in sv.Pinlist or applied(element, Output): 

    def create(self, sv, supervisor, svlist, args):                                          
237:             elif applied(element, Output):                                                             

def makebox(svlist, autotest):                                                
380:         if Unused in sv.Object: unusedlist=[applied (x, Unused) for x in sv.Object[Unused].value]
387:                     showed=applied(nam, Show)                            
388:                     counted=applied(showed, Count)                     
410:                 if applied(nam, f) and not f==Pin: ok=False            

### whand_critic.py:
def build_effects(sv):
53:             cau=applied(eff, Old)+applied(eff, Begin)+applied(eff, End)+applied(eff, Change) \
54:                  +applied(eff, Not)+applied(eff, All)+applied(eff, Any)              

def criticize(sv):
169:     seeds=[Start]+[x for x in sv.Object if applied(x, Pin) or applied(x, Key)]
188:                         if applied(cau1, Old) or applied(cau2, Old): bad=False
189:                         if applied(name, cau1) or applied(name, cau2): bad=False

def find_timing(sv, nom="", parent="", effct={}, timg={}, seeds=[]):
242:             if applied(nom, eff):                                                  

### whand_initial.py:
def start_values(sv):
142:                 fst=applied(nom, Store)                             

def initialize_simple(sv):
235:         elif applied(nom, Change): nod.value=[(None, 0)]                    

def verif_init(sv):
317:                     or applied(nom, Show) \
318:                     or applied(nom, Unused) ): continue                        

def make_delayed_list(sv):
351:         elif applied(nam, Begin) or applied(nam, End) or applied(nam, Pin) or applied(nam, Key) \
352:              or applied(nam, Measure) or applied(nam, Read): nod.isdelayed=True

def make_active_list(sv):                                                                                            
374:             if nam in sv.Volatile or sv.Object[nam].isdelayed or applied(nam, Old): 

def list_objects(sv, verbose):
591:                 if applied(nom, x): ok=False

### whand_operators.py:
282: Warn_never_applied="*** Warning: function is never applied ***"

### whand_runtime.py:
def update_loop(sv):
90:             if applied(nom, Pin) or applied(nom, Key): sv.Pinstate[nom]=Vrai if status else Faux

def updateval(sv):                                                               
188:         if applied(nom, Old):                                                         
237:                 if applied(nom, Store): bufstore(sv, applied(nom, Store), res.value)  

def value_has_changed(sv, nod, res, ch):
296:         if applied(nom, x) and nod.lastchange!=sv.Current_time and sv.Current_time>0:

def init_outputs(sv):
1364:         if applied(nom, Output) or applied(nom, Command) or applied(nom, Write):

def clear_outputs(sv):
1377:         if applied(nom, Output):

def link_output(sv, nom):
1418:     nb=applied(nom, Output)                                                   
1425:     nb=applied(nom, Command)                                              
1435:     nb=applied(nom, Write)                                                     
1442:     li=applied(nom, Display)                                                    

### whand_tools.py:
12: Dic_applied={}                                    

def is_glitch(expr):
103:         nam=applied(expr, gl)                                                       

def get_nature(sv, expr, hint=All_natures[:]):
149:     elif applied(expr, Store): nat=Lst[:]                                                       
150:     elif applied(expr, Cumul) or applied(expr, Steps): nat=Lst[:]          

290: def applied(expr, root):
303:     applied=""
305:         if expr in Dic_applied: return Dic_applied[expr]                  
308:             applied=block
309:         Dic_applied[expr]=applied               
310:     return applied
